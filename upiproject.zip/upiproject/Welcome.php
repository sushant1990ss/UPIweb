<?php
session_start();
if (!isset($_SESSION['email']) || $_SESSION['loggedin'] != true) {
    header('location : /upiproject/index.php');
} else {
    include "utility\_dbconnect.php";
    $email = $_SESSION['email'];
    $Sql = "SELECT * FROM `users` WHERE email = '$email';";
    $result = mysqli_query($conn, $Sql);
    while ($row = mysqli_fetch_assoc($result)) {
        $name = $row["username"];
        $userId = $row["userId"];
        $currBal = $row["currBal"];
    }
}

?>
<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>Welcome - <?php echo $name ?></title>
</head>

<body>
    <?php require "utility\_nav.php"; ?>

    <div class="container my-3 ">
        <div class="alert alert-success" role="alert">
            <h2 class="alert-heading text-dark">Welcome - <?php echo $name ?></h2>
            <p>Hey how are you doing? Welcome to UPIweb. You are logged in as <?php echo $name ?>. Aww yeah, you successfully read this important alert message. This example text is going to run a bit longer so that you can see how spacing within an alert works with this kind of content.</p>
            <div class="card text-center">
                <div class="card-header">
                    Details
                </div>
                <div class="card-body text-dark">
                    <h2 class="card-title">Available Balance</h2>
                    <h3 class="card-text"><?php if (isset($currBal)) {
                                                echo $currBal . '/-';
                                            } else {
                                                echo '0/-';
                                            } ?></h3>

                </div>

            </div>

        </div>
        <h2 class="text-center">Transactions</h2>
        <div class="container">
            <table class="table table-dark table-striped">
                <thead>
                    <tr>
                        <th scope="col">SNo.</th>
                        <th scope="col">Credit</th>
                        <th scope="col">Debit</th>
                        <th scope="col">Balance</th>
                        <th scope="col">Date&Time</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    include "utility\_dbconnect.php";
                    $sql1 = "SELECT `amount`, `debit` ,`credit` ,`date` FROM `transactions` WHERE `email_Id` LIKE '$email';";
                    $result1 = mysqli_query($conn, $sql1);
                    $num = mysqli_num_rows($result1);
                    $sno = 1;
                    if ($num != 0) {

                        while ($num > 0) {
                            $row1 = mysqli_fetch_assoc($result1);
                            $amount = $row1["amount"];
                            $credit = $row1["credit"];
                            $debit = $row1["debit"];
                            $date = $row1["date"];

                            echo '<tr>
                            <th scope="row">' . $sno . '</th>
                            <td>' . $credit . '</td>
                            <td>' . $debit . '</td>
                            <td>' . $amount . '</td>
                            <td>' . $date . '</td>
                            </tr>';
                            $sno++;
                            $num--;
                        }
                    } else {
                        echo '<h1>No recoeds found</h1>';
                    }

                    ?>


                </tbody>
            </table>

        </div>



        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>
</body>

</html>