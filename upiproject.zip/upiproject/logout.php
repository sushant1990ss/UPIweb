<?php
session_start();

session_unset();
session_destroy();

header("location: index.php");
echo"<h1>logout success</h1>";
exit;
?>