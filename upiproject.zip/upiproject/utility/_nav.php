<?php


if (isset($_SESSION['email']) && $_SESSION['loggedin'] == true) {
  $loggedIn = true;
} else {
  $loggedIn = false;
}

?>


<!-- Modal -->



<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Login Here!!</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="\upiproject\index.php" method="post">
          <div class="mb-3">
            <label for="email" class="form-label">Email address</label>
            <input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp">

          </div>
          <div class="mb-3">
            <label for="lpassword" class="form-label">Password</label>
            <input type="lpassword" class="form-control" id="lpassword" name="lpassword">
          </div>

          <button type="submit" class="btn btn-success">Login</button>
        </form>

      </div>

    </div>
  </div>
</div>


<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">UPIweb</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      <?php
      if($loggedIn){
        echo 
        '<li class="nav-item">
        <a class="nav-link active" aria-current="page" href="welcome.php">Dashboard</a>
        </li>';
      }else{
        echo 
          '<li class="nav-item">
            <a class="nav-link active" aria-current="page" href="index.php">Home</a>
          </li>';
      }
      ?>
      <?php
      if($loggedIn){
        echo
        '<li class="nav-item dropdown">
            <a class="nav-link active dropdown-toggle mx-2" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              Option
            </a>
            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
              <li><a class="dropdown-item" href="\upiproject\addmoney.php">Add Amount</a></li>
              
              <li><hr class="dropdown-divider"></li>
              <li><a class="dropdown-item" href="\upiproject\withdraw.php">Withdraw</a></li>
            </ul>
          </li>';
         }
      ?>
        
          <li class="nav-item">
            <a class="nav-link active" href="#">Contact us</a>
          </li>
        </ul>
        

      <?php
      if ($loggedIn) {
        echo '<a class="btn btn-outline-success mx-5" href="/upiproject/logout.php" type="submit" >Logout</a>';
      } else {
        echo '<button class="btn btn-outline-success " data-bs-toggle="modal" data-bs-target="#exampleModal">Login</button>';
      }
      ?>

    </div>
  </div>
</nav>