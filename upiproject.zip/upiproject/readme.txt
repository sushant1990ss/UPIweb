Before use UPIweb Please create a database with the name of
DBname="upiweb"
Tables name:
  1.users{
	userId-INT autoincrement and primery
	username-Varchar [50]
	email-Varchar [50] Unique
	password-Varchar [50]
	phone_number-Varchar [13]
	address-Varchar [100]
	currBal-INT [20]
	

	}
  2.transactions{
	id-INT autoincreament and primery
	amount-INT [20]
	debit-INT [20]
	credit-INT [20]
	email_id-varchar[100]
	date-datetime and currenttimestamp


	}